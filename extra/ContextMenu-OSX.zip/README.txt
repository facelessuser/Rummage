In order to use this workflow to add Rummage to OSX context menu, first you need to do the following:

The first task is to make a symlink to Rummage. Assuming you've placed Rummage in the Applications folder,
and that you have a ~/bin directory in your path, you can run:

ln -s /Applications/Rummage.app/Contents/MacOS/Rummage ~/bin/Rummage

Then add the workflow under ~/Library/Services. It should show up under "Services" for files and folders.
