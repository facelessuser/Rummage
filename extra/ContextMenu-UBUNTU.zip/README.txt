Context menu support for Ubuntu (Nautilus).

Place file in ~/.gnome2/nautilus-scripts.  Make script executable.

If calling the Rummage binary, modify "RUMMAGE_PATH" to point to the binary.

If calling the Rummage python script, modify "RUMMAGE_SCRIPT" to point to the rummage script and then modify "RUN_SCIPT" to be "True".
