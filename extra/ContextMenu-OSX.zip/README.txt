In order to use this workflow to add Rummage to OSX context menu,
you need to place the workflow in ~/Library/Services.

The workflow assumes Rummage is installed in /Applications.
If it is installed in a different location, you will have to
edit the workflow.

It should show up under "Services" for files and folders in the
context menu.
